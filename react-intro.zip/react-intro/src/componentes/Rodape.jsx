// Rodape.jsx
export default function Rodape() {

    return (
        <div className="rodape">
            Todos os direitos reservados
        </div>
    )
}
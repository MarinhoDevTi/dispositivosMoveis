// Menu.jsx
export default function Menu () {

    return (
        <div className="menu">
            <a href="#">Home</a>
            <a href="#">Filmes</a>
            <a href="#">Contato</a>
        </div>
    )
}
